<?php

session_start();

if (isset($_GET['lang'])) {

    $_SESSION['lang'] = $_GET['lang'];

}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $conn = new mysqli("localhost", "root", "", "training_site");

    if ($conn->connect_error) {

        die("Connection failed: " . $conn->connect_error);

    }

    $email = $_POST['email'];

    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, full_name, password FROM users WHERE email = ?");

    $stmt->bind_param("s", $email);

    $stmt->execute();

    $stmt->store_result();

    if ($stmt->num_rows > 0) {

        $stmt->bind_result($id, $full_name, $hashed_password);

        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {

            $_SESSION['user_name'] = $full_name;

            $_SESSION['user_role'] = 'user';

            $_SESSION['user_id'] = $id;

            header("Location: index.php");

            exit();

        } else {

            $error = "كلمة المرور غير صحيحة";

        }

    } else {

        $error = "البريد الإلكتروني غير موجود";

    }

    $stmt->close();

    $conn->close();

}

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<title>تسجيل دخول المستخدم</title>
<style>

        body {

            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;

            background: linear-gradient(135deg, #4a90e2, #357ABD);

            color: #fff;

            height: 100vh;

            margin: 0;

            display: flex;

            justify-content: center;

            align-items: center;

        }

        .login-container {

            background: rgba(255, 255, 255, 0.1);

            padding: 30px 40px;

            border-radius: 12px;

            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);

            width: 320px;

            text-align: center;

        }

        .login-container h2 {

            margin-bottom: 25px;

            font-weight: 700;

        }

        .login-container input[type="email"],

        .login-container input[type="password"] {

            width: 100%;

            padding: 12px 15px;

            margin: 10px 0 20px 0;

            border: none;

            border-radius: 8px;

            font-size: 15px;

        }

        .login-container button {

            background-color: #285cba;

            border: none;

            padding: 12px 0;

            width: 100%;

            color: white;

            font-size: 16px;

            border-radius: 8px;

            cursor: pointer;

            transition: background-color 0.3s ease;

        }

        .login-container button:hover {

            background-color: #1f4595;

        }

        .error-message {

            background-color: rgba(255, 0, 0, 0.7);

            padding: 10px;

            border-radius: 8px;

            margin-bottom: 15px;

            font-weight: 600;

        }

        .back-link {

            margin-top: 15px;

            display: inline-block;

            color: #dce6f7;

            text-decoration: none;

            font-size: 14px;

        }

        .back-link:hover {

            text-decoration: underline;

        }

        .signup-link {

            margin-top: 10px;

            font-size: 14px;

            color: #fff;

        }

        .signup-link a {

            color: #fff;

            text-decoration: underline;

        }

        .signup-link a:hover {

            text-decoration: none;

        }

    .signup-link {

        margin-top: 10px;

        font-size: 14px;

        color: #fff;

    }

    .signup-link a {

        color: #fff;

        text-decoration: underline;

    }

    .signup-link a:hover {

        text-decoration: none;

    }
</style>
</head>
<body>
<div class="login-container">
<h2>تسجيل دخول المستخدم</h2>
<?php if (isset($error)) : ?>
<div class="error-message"><?= htmlspecialchars($error) ?><p class="signup-link">لا تملك حسابًا؟ <a href="register.html">سجّل عضويتك الآن</a></p>
</div>
<?php endif; ?>
<form method="POST" action="login.php" novalidate>
<input type="email" name="email" placeholder="البريد الإلكتروني" required />
<input type="password" name="password" placeholder="كلمة المرور" required />
<button type="submit">دخول</button>
</form>
<a class="back-link" href="index.php">&larr; العودة إلى الصفحة الرئيسية</a>
<p class="signup-link">لا تملك حسابًا؟ <a href="register.html">سجّل عضويتك الآن</a></p>
</div>
</body>
</html>
 