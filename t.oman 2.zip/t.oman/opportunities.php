<?php
$conn = new mysqli("localhost", "root", "", "training_site");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
 
$specialization = isset($_GET['specialization']) ? $_GET['specialization'] : "All";
 
if ($specialization == "All") {
    $query = "SELECT * FROM opportunities";
} else {
    $query = "SELECT * FROM opportunities WHERE specialization = '$specialization'";
}
 
$result = $conn->query($query);
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Available Training Opportunities</title>
<style>
    body {
      background-color: #f0f2f5;
      font-family: 'Tahoma', sans-serif;
      color: #1a1a1a;
      margin: 0;
      padding: 30px 20px;
      text-align: center;
    }
    h2 {
      color: #2c3e50;
      margin-bottom: 30px;
    }
    table {
      margin: 0 auto;
      border-collapse: collapse;
      width: 90%;
      background-color: #fff;
    }
    th, td {
      padding: 12px;
      border: 1px solid #ccc;
    }
    th {
      background-color: #3498db;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    a.button {
      display: inline-block;
      margin-top: 30px;
      padding: 10px 20px;
      background-color: #2c3e50;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }
</style>
</head>
<body>
<h2>Training Opportunities for: <?php echo htmlspecialchars($specialization); ?></h2>
 
 <table>
<tr>
<th>Title</th>
<th>Company</th>
<th>Location</th>
<th>Duration</th>
<th>Specialization</th>
<th>Minimum GPA</th>
<th>Email</th>
<th>Phone</th>
</tr>
<?php while ($row = $result->fetch_assoc()): ?>
<tr>
<td><?php echo htmlspecialchars($row['title']); ?></td>
<td><?php echo htmlspecialchars($row['company']); ?></td>
<td><?php echo htmlspecialchars($row['location']); ?></td>
<td><?php echo htmlspecialchars($row['duration']); ?></td>
<td><?php echo htmlspecialchars($row['specialization']); ?></td>
<td><?php echo htmlspecialchars($row['GPA']); ?></td> <!-- Capital letters -->
<td><?php echo htmlspecialchars($row['email']); ?></td>
<td><?php echo htmlspecialchars($row['phone_number']); ?></td>
</tr>
<?php endwhile; ?>
</table>
 
 
  <a href="student_filter.html" class="button">← Back to Specialization Selection</a>
 
</body>
</html>