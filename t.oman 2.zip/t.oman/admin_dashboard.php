<?php
include 'db.php';
session_start();

// Add new opportunity
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_opportunity'])) {
    $title = $_POST['title'];
    $company = $_POST['company'];
    $specialization = $_POST['specialization'];
    $location = $_POST['location'];
    $GPA = $_POST['GPA'];
    $duration = $_POST['duration'];
    $email = $_POST['email'];
    $phone_number = $_POST['PHONE_NUMBER'];

    $stmt = $conn->prepare("INSERT INTO opportunities (title, company, specialization, location, GPA, duration, email, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $title, $company, $specialization, $location, $GPA, $duration, $email, $phone_number);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_dashboard.php");
    exit();
}

// Fetch all opportunities
$result = $conn->query("SELECT * FROM opportunities");
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8" />
  <title>Admin Dashboard - Manage Opportunities</title>
  <style>
    /* Reset and base */
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #121212;
      color: #eee;
      min-height: 100vh;
    }
    .container {
      max-width: 1100px;
      margin: 40px auto;
      padding: 0 20px;
    }
    a.button {
      display: inline-block;
      background: #2979ff;
      color: #fff;
      padding: 10px 20px;
      border-radius: 5px;
      text-decoration: none;
      margin-bottom: 25px;
      transition: background-color 0.3s ease;
    }
    a.button:hover {
      background: #5393ff;
    }
    h1 {
      font-weight: 700;
      margin-bottom: 25px;
      text-align: center;
      color: #bbdefb;
    }
    form {
      background: #1e1e1e;
      padding: 25px;
      border-radius: 8px;
      margin-bottom: 40px;
      box-shadow: 0 0 12px rgba(0, 0, 0, 0.6);
    }
    form h2 {
      margin-top: 0;
      margin-bottom: 15px;
      color: #82b1ff;
    }
    form label {
      display: block;
      margin: 15px 0 5px;
      font-weight: 600;
      color: #90caf9;
    }
    form input[type="text"],
    form input[type="email"],
    form select {
      width: 100%;
      padding: 10px 12px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      background: #333;
      color: #eee;
      transition: background-color 0.3s ease;
    }
    form input[type="text"]:focus,
    form input[type="email"]:focus,
    form select:focus {
      background: #444;
      outline: none;
    }
    form button {
      margin-top: 20px;
      background: #2979ff;
      border: none;
      padding: 12px 25px;
      font-size: 16px;
      border-radius: 5px;
      color: white;
      cursor: pointer;
      font-weight: 700;
      transition: background-color 0.3s ease;
    }
    form button:hover {
      background: #5393ff;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      box-shadow: 0 0 15px rgba(41, 121, 255, 0.25);
      border-radius: 8px;
      overflow: hidden;
    }
    th, td {
      padding: 12px 15px;
      text-align: center;
    }
    thead {
      background: #2979ff;
      color: white;
      font-weight: 600;
    }
    tbody tr {
      background: #1e1e1e;
      transition: background-color 0.3s ease;
    }
    tbody tr:hover {
      background: #3949ab;
    }
    .actions a {
      color: #82b1ff;
      margin: 0 8px;
      text-decoration: none;
      font-weight: 600;
      cursor: pointer;
    }
    .actions a:hover {
      text-decoration: underline;
    }
    @media (max-width: 768px) {
      form label, form input, form select, form button {
        font-size: 14px;
      }
      th, td {
        padding: 8px 6px;
        font-size: 14px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <a href="index.php" class="button">← Back to Home</a>

    <h1>Admin Dashboard - Manage Opportunities</h1>

    <form method="POST" action="admin_dashboard.php" autocomplete="off">
      <h2>Add New Opportunity</h2>

      <label for="title">Title</label>
      <input type="text" name="title" id="title" placeholder="Opportunity Title" required />

      <label for="company">Company</label>
      <input type="text" name="company" id="company" placeholder="Company Name" required />

      <label for="location">Location</label>
      <input type="text" name="location" id="location" placeholder="Location" required />

      <label for="GPA">Minimum GPA</label>
      <input type="text" name="GPA" id="GPA" placeholder="e.g., 3.5" required />

      <label for="duration">Duration</label>
      <input type="text" name="duration" id="duration" placeholder="Duration (e.g., 3 months)" required />

      <label for="email">Contact Email</label>
      <input type="email" name="email" id="email" placeholder="Email Address" required />

      <label for="PHONE_NUMBER">Phone Number</label>
      <input type="text" name="PHONE_NUMBER" id="PHONE_NUMBER" placeholder="Phone Number" required />

      <label for="specialization">Specialization</label>
      <select name="specialization" id="specialization" required>
        <option value="">-- Select Specialization --</option>
        <option value="Information Technology">Information Technology</option>
        <option value="Marketing">Marketing</option>
        <option value="Graphic Design">Graphic Design</option>
        <option value="Business Administration">Business Administration</option>
        <option value="Accounting">Accounting</option>
        <option value="Engineering">Engineering</option>
        <option value="Human Resources">Human Resources</option>
        <option value="Logistics">Logistics</option>
        <option value="Finance">Finance</option>
        <option value="Law">Law</option>
        <option value="All">All</option>
      </select>

      <button type="submit" name="add_opportunity">Add Opportunity</button>
    </form>

    <table>
      <thead>
        <tr>
          <th>Title</th>
          <th>Company</th>
          <th>Location</th>
          <th>GPA</th>
          <th>Duration</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Specialization</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['title']); ?></td>
            <td><?= htmlspecialchars($row['company']); ?></td>
            <td><?= htmlspecialchars($row['location']); ?></td>
            <td><?= htmlspecialchars($row['GPA']); ?></td>
            <td><?= htmlspecialchars($row['duration']); ?></td>
            <td><?= htmlspecialchars($row['email']); ?></td>
            <td><?= htmlspecialchars($row['phone_number']); ?></td>
            <td><?= htmlspecialchars($row['specialization']); ?></td>
            <td class="actions">
              <a href="delete_opportunity.php?id=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this opportunity?');">Delete</a> |
              <a href="view_registrations.php?opportunity_id=<?= $row['id']; ?>">View Applicants</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>

  </div>
</body>
</html>
