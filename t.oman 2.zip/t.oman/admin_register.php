<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("localhost", "root", "", "training_site");

    if ($conn->connect_error) {
        die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
    }

    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // التحقق من تطابق كلمتي المرور
    if ($password !== $confirm_password) {
        $error = "كلمتا المرور غير متطابقتين";
    } else {
        // تشفير كلمة المرور
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // التحقق من عدم وجود البريد مسبقًا
        $check = $conn->prepare("SELECT id FROM admins WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "البريد الإلكتروني مستخدم مسبقًا";
        } else {
            $stmt = $conn->prepare("INSERT INTO admins (full_name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $full_name, $email, $hashed_password);

            if ($stmt->execute()) {
                $success = "تم إنشاء الحساب بنجاح. يمكنك تسجيل الدخول الآن.";
            } else {
                $error = "حدث خطأ أثناء التسجيل.";
            }

            $stmt->close();
        }

        $check->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>تسجيل حساب أدمن</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h2>إنشاء حساب أدمن</h2>

    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>

    <form method="POST" action="admin_register.php">
      <input type="text" name="full_name" placeholder="الاسم الكامل" required>
      <input type="email" name="email" placeholder="البريد الإلكتروني" required>
      <input type="password" name="password" placeholder="كلمة المرور" required>
      <input type="password" name="confirm_password" placeholder="تأكيد كلمة المرور" required>
      <button type="submit">تسجيل</button>
    </form>
  </div>
</body>
</html>
