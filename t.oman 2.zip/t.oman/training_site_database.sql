
CREATE DATABASE IF NOT EXISTS training_site;
USE training_site;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS opportunities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(100),
  company VARCHAR(100),
  location VARCHAR(100),
  duration VARCHAR(50),
  description TEXT,
  specialization VARCHAR(100)
);
