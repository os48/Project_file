
<?php
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $company = $_POST['company'];
  $title = $_POST['title'];
  $spec = $_POST['specialization'];
  $location = $_POST['location'];
  $duration = $_POST['duration'];
  $desc = $_POST['description'];
  $stmt = $conn->prepare("INSERT INTO opportunities (title, company, location, duration, description, specialization) VALUES (?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("ssssss", $title, $company, $location, $duration, $desc, $spec);
  $stmt->execute();
  echo "Opportunity added successfully.";
}
?>
