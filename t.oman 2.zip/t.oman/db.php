<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "training_site";

$conn = new mysqli($servername, $username, $password, $database);

// تحقق من الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال: " . $conn->connect_error);
}
?>
