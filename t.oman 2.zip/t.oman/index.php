[file name]: index.php

[file content begin]
<?php

session_start();

$username = $_SESSION['user_name'] ?? null;

$userRole = $_SESSION['user_role'] ?? null;  // 'admin' أو 'user' أو null إذا غير مسجل دخول

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>منصة تدريب عمان</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet" />
<style>

    /* نفس التنسيقات السابقة ... */

    * {

      box-sizing: border-box;

      margin: 0;

      padding: 0;

      font-family: 'Cairo', sans-serif;

    }

    body {

      background: linear-gradient(to bottom right, #f0f4f8, #ffffff);

      color: #333;

      transition: direction 0.3s ease;

    }

    header {

      background: #1e88e5;

      color: white;

      padding: 15px 30px;

      display: flex;

      align-items: center;

      justify-content: space-between;

      box-shadow: 0 2px 8px rgba(0,0,0,0.1);

      gap: 20px;

      flex-wrap: wrap;

    }

    .logo {

      font-size: 24px;

      font-weight: bold;

      flex-shrink: 0;

    }

    .main-nav {

      flex-grow: 1;

      display: flex;

      justify-content: center;

      gap: 20px;

    }

    .main-nav .nav-link {

      color: white;

      text-decoration: none;

      font-size: 16px;

      padding: 8px 12px;

      border-radius: 6px;

      transition: background-color 0.3s ease;

      white-space: nowrap;

    }

    .main-nav .nav-link:hover {

      background-color: rgba(255,255,255,0.3);

    }

    .nav-actions {

      display: flex;

      align-items: center;

      gap: 10px;

      flex-shrink: 0;

    }

    .user-greeting {

      font-weight: bold;

      font-size: 16px;

      margin-inline-start: 10px;

      white-space: nowrap;

    }

    .login-btn, .logout-btn, .lang-btn {

      background: transparent;

      border: 1px solid white;

      color: white;

      padding: 6px 12px;

      border-radius: 6px;

      cursor: pointer;

      font-size: 14px;

      text-decoration: none;

      transition: 0.3s;

      white-space: nowrap;

    }

    .login-btn:hover, .logout-btn:hover, .lang-btn:hover {

      background: white;

      color: #1e88e5;

    }

    .hero {

      text-align: center;

      padding: 80px 20px;

      background: linear-gradient(rgba(30,136,229,0.8), rgba(30,136,229,0.8)), url('https://images.unsplash.com/photo-1581093588401-4a6d84a04a65?auto=format&fit=crop&w=1350&q=80') center/cover no-repeat;

      color: white;

    }

    .hero h1 {

      font-size: 40px;

      margin-bottom: 10px;

    }

    .hero p {

      font-size: 18px;

      opacity: 0.95;

    }

    .features {

      display: flex;

      flex-wrap: wrap;

      justify-content: center;

      gap: 20px;

      padding: 50px 20px;

    }

    .feature-card {

      background: white;

      width: 280px;

      padding: 20px;

      border-radius: 12px;

      box-shadow: 0 4px 12px rgba(0,0,0,0.08);

      transition: 0.3s;

      text-align: start;

    }

    .feature-card:hover {

      transform: translateY(-5px);

    }

    .feature-card h3 {

      margin-bottom: 10px;

      color: #1e88e5;

    }

    footer {

      background: #1b1b1b;

      color: white;

      text-align: center;

      padding: 20px;

      font-size: 14px;

    }

    @media (max-width: 700px) {

      header {

        flex-direction: column;

        align-items: stretch;

        gap: 15px;

      }

      .main-nav {

        justify-content: center;

      }

      .nav-actions {

        justify-content: center;

        flex-wrap: wrap;

      }

      .hero h1 {

        font-size: 28px;

      }

      .hero p {

        font-size: 16px;

      }

      .features {

        flex-direction: column;

        align-items: center;

      }

    }
</style>
</head>
<body>
<header>
<div class="logo" id="site-title">منصة تدريب عمان</div>
<nav class="main-nav">
<!-- Updated About Us link with ID for JavaScript access -->
<a href="about.html" class="nav-link" id="nav-about">من نحن</a>
<?php if ($username): ?>
<?php if ($userRole === 'admin'): ?>
<a href="admin_dashboard.php" class="nav-link" id="nav-dashboard">لوحة التحكم</a>
<?php elseif ($userRole === 'user'): ?>
<a href="student_filter.html" class="nav-link" id="nav-opportunities">البحث عن الفرص</a>
<?php endif; ?>
<?php endif; ?>
</nav>
<div class="nav-actions">
<?php if ($username): ?>
<span class="user-greeting">مرحباً، <?= htmlspecialchars($username) ?></span>
<form method="post" action="logout.php" style="display:inline;">
<button class="logout-btn" type="submit">تسجيل خروج</button>
</form>
<?php else: ?>
<a href="login.php" class="login-btn" id="login-user-btn">دخول المستخدم</a>
<a href="admin_login.php" class="login-btn" id="login-admin-btn">دخول الإدارة</a>
<?php endif; ?>
<button class="lang-btn" onclick="toggleLang()">English</button>
</div>
</header>
<section class="hero">
<h1 id="hero-title">منصة تدريب عمان</h1>
<p id="hero-desc">منصة ذكية تربط الباحثين عن التدريب بالجهات المعتمدة في مختلف التخصصات</p>
</section>
<section class="features">
<div class="feature-card">
<h3 id="f1-title">واجهة سهلة</h3>
<p id="f1-desc">تصميم بسيط وسهل الاستخدام لجميع الفئات</p>
</div>
<div class="feature-card">
<h3 id="f2-title">فرص متنوعة</h3>
<p id="f2-desc">برامج تدريب داخلية وخارجية في مختلف المجالات</p>
</div>

</section>
<footer>
<p>&copy; 2025 منصة تدريب عمان. جميع الحقوق محفوظة.</p>
</footer>
<script>

    let currentLang = "ar";

    const langData = {

      ar: {

        "site-title": "منصة تدريب عمان",

        "hero-title": "منصة تدريب عمان",

        "hero-desc": "منصة ذكية تربط الباحثين عن التدريب بالجهات المعتمدة في مختلف التخصصات",

        "f1-title": "واجهة سهلة",

        "f1-desc": "تصميم بسيط وسهل الاستخدام لجميع الفئات",

        "f2-title": "فرص متنوعة",

        "f2-desc": "برامج تدريب داخلية وخارجية في مختلف المجالات",

        "f3-title": "تتبع الطلبات",

        "f3-desc": "إمكانية متابعة حالة الطلب بشكل مباشر",

        "nav-about": "من نحن",

        "nav-dashboard": "لوحة التحكم",

        "nav-opportunities": "البحث عن الفرص",

        "login-user": "دخول المستخدم",

        "login-admin": "دخول الإدارة",

        "logout": "تسجيل خروج",

        "lang-btn": "English",

        "about-url": "about.html" // Added Arabic URL

      },

      en: {

        "site-title": "Oman Training Platform",

        "hero-title": "Oman Training Platform",

        "hero-desc": "A smart platform connecting trainees with accredited institutions in various fields",

        "f1-title": "Easy Interface",

        "f1-desc": "Simple and user-friendly design for all categories",

        "f2-title": "Diverse Opportunities",

        "f2-desc": "Internal and external training programs in various fields",

        "f3-title": "Request Tracking",

        "f3-desc": "Track the status of your request directly",

        "nav-about": "About Us",

        "nav-dashboard": "Dashboard",

        "nav-opportunities": "Find Opportunities",

        "login-user": "User Login",

        "login-admin": "Admin Login",

        "logout": "Logout",

        "lang-btn": "العربية",

        "about-url": "about_en.html" // Added English URL

      }

    };

    function toggleLang() {

      currentLang = currentLang === "ar" ? "en" : "ar";

      document.documentElement.lang = currentLang;

      document.documentElement.dir = currentLang === "ar" ? "rtl" : "ltr";

      document.querySelector(".lang-btn").textContent = langData[currentLang]["lang-btn"];

      // ترجمة النصوص

      for (const key in langData[currentLang]) {

        const el = document.getElementById(key);

        if (el) {

          // Special handling for about URL

          if (key === "nav-about") {

            el.textContent = langData[currentLang][key];

            // Update the href attribute for the About link

            el.href = langData[currentLang]["about-url"];

          } else {

            el.textContent = langData[currentLang][key];

          }

        }

      }

      // تحديث أزرار الدخول والخروج

      const loginUserBtn = document.getElementById('login-user-btn');

      const loginAdminBtn = document.getElementById('login-admin-btn');

      const logoutBtn = document.querySelector('.logout-btn');

      if (currentLang === "ar") {

        if(loginUserBtn) loginUserBtn.textContent = langData.ar["login-user"];

        if(loginAdminBtn) loginAdminBtn.textContent = langData.ar["login-admin"];

        if(logoutBtn) logoutBtn.textContent = langData.ar["logout"];

      } else {

        if(loginUserBtn) loginUserBtn.textContent = langData.en["login-user"];

        if(loginAdminBtn) loginAdminBtn.textContent = langData.en["login-admin"];

        if(logoutBtn) logoutBtn.textContent = langData.en["logout"];

      }

    }
</script>
</body>
</html>

[file content end]
 
